# CntNumber
DSA NO.1

將你嘅中文數字交畀我,我會將佢變做阿拉伯數字.

BTW,我好靚仔!~

# Usage example
```python
import CntNumber
CntNumber.toNum('九千九百九十九萬九千九百九十九億九千九百九十九萬九千九百九十九')
```
